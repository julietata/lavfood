<div class="flex w-full h-24 px-8 py-3 justify-between items-center">
    <a href="home.php" class="h-full">
        <img src="../asset/LAvFood-logo.png" alt="" class="h-full">
    </a>
    <div>
        <a href="./pages/auth/login.php" class="border-2 border-amber-100 py-2 px-4 text-amber-100 font-semibold text-lg rounded-md mx-1 cursor-pointer">Login</a>
    </div>
</div>